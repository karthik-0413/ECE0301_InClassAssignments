
#ifndef DCCURRENTSOURCE_H
#define DCCURRENTSOURCE_H

#include <iostream>
#include <string>
#include <fstream>
#include <random>
#include <cmath>
#include <iomanip>
using namespace std;

//Class Definition for DCCurrentSource Class
class DCCurrentSource
{
    private:
        double IS;
    public:
        DCCurrentSource();
        //void setIS(double);
        //double getIS() const;
        //double getPower() const;
        //void out7(ofstream&);
};

#endif
