#include "Signal.h"
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

//Default Constructor
Signal::Signal()
{
    numSample = 101;
	sampleRate = 100;
	initialTime = 0;
    setFunction("x");
    setExpression("0");
    signal.resize(numSample, 0);
    time.resize(numSample, 0);
    fillTimeArray();
}

//Parameterized Constructor
Signal::Signal(unsigned int num, double rate, double time2, const string& file)
{
    numSample = num;
    sampleRate = rate;
    initialTime = time2;
    setFunction(file);
    //setExpression(expr);
    signal.resize(numSample, 0);
    time.resize(numSample, 0);
    fillTimeArray();
}

//Mutator Function to set NumSample
void Signal::setNumSample(unsigned int num)
{
    numSample = num;
    
    time.resize(numSample);
    signal.resize(numSample);

    fillTimeArray();
}

//Mutator Function to set SampleRate
void Signal::setSampleRate(double num)
{
    sampleRate = num;

    fillTimeArray();
}

//Mutator Function to set InitialTime
void Signal::setInitialTime(double num)
{
    initialTime = num;

    fillTimeArray();
}

//Mutator Function to set Function
void Signal::setFunction(const string& label)
{
    function = label;
    filename = "diff_eqn_soln_" + label;
}

//Mutator Function to set Expression
void Signal::setExpression(const string& express)
{
    expression = express;
}

//Accessor Function to get NumSample
unsigned int Signal::getNumSample() const
{
    return numSample;
}

//Accessor Function to get SampleRate
double Signal::getSampleRate() const
{
    return sampleRate;
}

//Accessor Function to get initialTime
double Signal::getInitialTime() const
{
    return initialTime;
}

//Accessor Function to get function
string Signal::getFunction() const
{
    return function;
}

//Accessor Function to get filename
string Signal::getFilename() const
{
    return filename;
}

//Accessor Function to get expression
string Signal::getExpression() const
{
    return expression;
}

//Accessor Function to get signal vector
vector<double> Signal::getSignal() const
{
    return signal;
}

//Accessor Function to get time vector
vector<double> Signal::getTime() const
{
    return time;
}

//Overloaded Accessor Function to get signal vector
double Signal::getSignal2(unsigned int i) const
{
    return signal[i];
}

//Overloaded Accessor Function to get time vector
double Signal::getTime2(unsigned int i) const
{
    return time[i];
}

//Member Function that puts 100 numbers from 0 - 100 going up by the sample rate every iteration in the timeptr pointer
void Signal::fillTimeArray()
{
    //For-Loop to fill the timeptr pointer array with the numbers explained above
    for (unsigned int i = 0; i < numSample; i++)
    {
        time[i] = initialTime + (i/sampleRate);
    }
}

//Member Function to graph sine graph
void Signal::fillSignalArray(double amp, double freq, double phase)
{
    for (unsigned int i = 0; i < numSample; i++)
    {
        signal[i] = amp * cos((freq * time[i]) + phase);
    }
}

//Member Function to graph exponential graph
void Signal::fillExponentialArray(double TC, double initial)
{
    for (unsigned int i = 0; i < numSample; i++)
    {
        signal[i] = initial * exp(-(time[i] - initialTime) / TC);
    }

    //If-else loop to determine sign of the expression
    expression = textNum(initial) + " exp( -";
    if (initialTime == 0)
    {
        expression+="t  ";
    }
    else if (initialTime<0)
    {
        expression += "(t + " + textNum(fabs(initialTime)) + ") ";
    }
    else
    {
        expression += "(t - " + textNum(fabs(initialTime)) + ") ";
    }
    
    if (TC == 1)
    {
        expression += ")";
    }
    else
    {
        expression += "/ " + textNum(TC) + " )";
    }
}

//Copy and Pasted the given function by the instructor
string Signal::textNum(double x) const
{
    if (x >= 100)
    {
        // large numbers truncated as int -> string

        return std::to_string(int(x));
    }
    else
    {
        // small numbers will get 3 digits
        string x_exp = std::to_string(x);

        // return 4 characters, or 5 if x<0
        return x_exp.substr(0, 4 + (x<0));
    }
}

//Member Function that sets the signal vector to all one number
void Signal::setConstant(double K)
{
    //writes the value of the parameter to all elements of the signal vector
    for (unsigned int i = 0; i < numSample; i++)
    {
        signal[i] = K;
    }

    //Sets the mathematical expression to the constant value
    setExpression(textNum(K));
}

//Rounding all of the value in the signal vector
void Signal::roundSignalRound()
{
    for (unsigned int i = 0; i < numSample; i++)
    {
        signal[i] = round(signal[i]);
    }
}

//Member Function that displays the numbers in each of the pointer array to the output file
void Signal::outFile()
{
    //Declaring a string variable that concatenates the filename given with .txt
    string name = filename + ".txt";

    //Declaring a output file
    ofstream out2;
    out2.open(name);

    //Displaying the number and statements in the matter that is required by us by the instructions
    out2 << "Default Signal:\n";
    out2 << "N: " << numSample << endl;
    out2 << "fs: " << sampleRate << "\n";
    out2 << "t0: " << initialTime << "\n";
    out2 << "Signal label: " << function << endl;
    out2 << "Matehmatical Expression: " << endl;
    out2 << "x(t): " << expression << endl;
    out2 << "Time and signal samples in .csv format" << endl;
    out2 << "t, x(t)\n-------" << endl;

    //For-Loop to displaying both the timeptr and signalptr pointer arrays to the output file
    for (unsigned int i = 0; i < numSample; i++)
    {
        out2 << time[i] << ", " << signal[i] << endl;
    }

    //Closing output file
    out2.close();
}
